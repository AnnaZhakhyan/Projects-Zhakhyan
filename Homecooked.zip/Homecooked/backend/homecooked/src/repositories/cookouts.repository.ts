import {inject} from '@loopback/core';
import {DefaultCrudRepository} from '@loopback/repository';
import {DbDataSource} from '../datasources';
import {Cookouts, CookoutsRelations} from '../models';

export class CookoutsRepository extends DefaultCrudRepository<
  Cookouts,
  typeof Cookouts.prototype.id,
  CookoutsRelations
> {
  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
  ) {
    super(Cookouts, dataSource);
  }
}
