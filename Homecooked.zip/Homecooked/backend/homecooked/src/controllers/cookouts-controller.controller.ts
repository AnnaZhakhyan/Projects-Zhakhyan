import {
  Count,
  CountSchema,
  Filter,
  FilterExcludingWhere,
  repository,
  Where,
} from '@loopback/repository';
import {
  post,
  param,
  get,
  getModelSchemaRef,
  patch,
  put,
  del,
  requestBody,
  response,
} from '@loopback/rest';
import {Cookouts} from '../models';
import {CookoutsRepository} from '../repositories';

export class CookoutsControllerController {
  constructor(
    @repository(CookoutsRepository)
    public cookoutsRepository : CookoutsRepository,
  ) {}

  @post('/cookouts')
  @response(200, {
    description: 'Cookouts model instance',
    content: {'application/json': {schema: getModelSchemaRef(Cookouts)}},
  })
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Cookouts, {
            title: 'NewCookouts',
            
          }),
        },
      },
    })
    cookouts: Cookouts,
  ): Promise<Cookouts> {
    return this.cookoutsRepository.create(cookouts);
  }

  @get('/cookouts/count')
  @response(200, {
    description: 'Cookouts model count',
    content: {'application/json': {schema: CountSchema}},
  })
  async count(
    @param.where(Cookouts) where?: Where<Cookouts>,
  ): Promise<Count> {
    return this.cookoutsRepository.count(where);
  }

  @get('/cookouts')
  @response(200, {
    description: 'Array of Cookouts model instances',
    content: {
      'application/json': {
        schema: {
          type: 'array',
          items: getModelSchemaRef(Cookouts, {includeRelations: true}),
        },
      },
    },
  })
  async find(
    @param.filter(Cookouts) filter?: Filter<Cookouts>,
  ): Promise<Cookouts[]> {
    return this.cookoutsRepository.find(filter);
  }

  @patch('/cookouts')
  @response(200, {
    description: 'Cookouts PATCH success count',
    content: {'application/json': {schema: CountSchema}},
  })
  async updateAll(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Cookouts, {partial: true}),
        },
      },
    })
    cookouts: Cookouts,
    @param.where(Cookouts) where?: Where<Cookouts>,
  ): Promise<Count> {
    return this.cookoutsRepository.updateAll(cookouts, where);
  }

  @get('/cookouts/{id}')
  @response(200, {
    description: 'Cookouts model instance',
    content: {
      'application/json': {
        schema: getModelSchemaRef(Cookouts, {includeRelations: true}),
      },
    },
  })
  async findById(
    @param.path.number('id') id: number,
    @param.filter(Cookouts, {exclude: 'where'}) filter?: FilterExcludingWhere<Cookouts>
  ): Promise<Cookouts> {
    return this.cookoutsRepository.findById(id, filter);
  }

  @patch('/cookouts/{id}')
  @response(204, {
    description: 'Cookouts PATCH success',
  })
  async updateById(
    @param.path.number('id') id: number,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Cookouts, {partial: true}),
        },
      },
    })
    cookouts: Cookouts,
  ): Promise<void> {
    await this.cookoutsRepository.updateById(id, cookouts);
  }

  @put('/cookouts/{id}')
  @response(204, {
    description: 'Cookouts PUT success',
  })
  async replaceById(
    @param.path.number('id') id: number,
    @requestBody() cookouts: Cookouts,
  ): Promise<void> {
    await this.cookoutsRepository.replaceById(id, cookouts);
  }

  @del('/cookouts/{id}')
  @response(204, {
    description: 'Cookouts DELETE success',
  })
  async deleteById(@param.path.number('id') id: number): Promise<void> {
    await this.cookoutsRepository.deleteById(id);
  }
}
