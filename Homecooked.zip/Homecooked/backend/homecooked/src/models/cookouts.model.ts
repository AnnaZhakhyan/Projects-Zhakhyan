import {Entity, model, property} from '@loopback/repository';

@model()
export class Cookouts extends Entity {
  @property({
    type: 'number',
    id: true,
    generated: true,
  })
  id?: number;

  @property({
    type: 'string',
    required: true,
  })
  dish: string;

  @property({
    type: 'string',
    required: true,
  })
  description: string;

  @property({
    type: 'string',
  })
  picture?: string;

  @property({
    type: 'string',
    required: true,
  })
  location: string;

  @property({
    type: 'date',
    required: true,
  })
  date: string;

  @property({
    type: 'string',
    required: true,
  })
  time: string;

  @property({
    type: 'number',
    required: true,
  })
  dining_option: number;

  @property({
    type: 'number',
    required: true,
  })
  allergens: number;

  @property({
    type: 'number',
    required: true,
  })
  price: number;


  constructor(data?: Partial<Cookouts>) {
    super(data);
  }
}

export interface CookoutsRelations {
  // describe navigational properties here
}

export type CookoutsWithRelations = Cookouts & CookoutsRelations;
