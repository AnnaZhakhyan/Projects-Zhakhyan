//
//  ContentView.swift
//  Register
//
//  Created by Philipp Ziglasch on 07.11.24.
//

import SwiftUI

struct ContentView: View {
    @State private var firstname = ""
    @State private var lastname = ""
    @State private var email = ""
    @State private var password = ""
    @State private var passwordRepeat = ""
    
    @State private var wrongFirstname = 0
    @State private var wrongLastname = 0
    @State private var wrongEmail = 0
    @State private var wrongPassword = 0
    @State private var wrongPasswordRepeat = 0
    
    var body: some View {
        ZStack {
            Color.orange
                    .ignoresSafeArea()
                Circle()
                    .scale(1.7)
                    .foregroundColor(.white.opacity(0.15))
                Circle()
                    .scale(1.35)
                    .foregroundColor(.white)
        
            VStack{
                Text("Register")
                    .font(.largeTitle)
                    .bold()
                    .padding()
                
                TextField("Firstname", text: $firstname)
                    .padding()
                    .frame(width: 300, height: 50)
                    .background(Color.black.opacity(0.05))
                    .cornerRadius(10)
                    .border(.red, width: CGFloat(wrongFirstname))
                
                TextField("Lastname", text: $lastname)
                    .padding()
                    .frame(width: 300, height: 50)
                    .background(Color.black.opacity(0.05))
                    .cornerRadius(10)
                    .border(.red, width: CGFloat(wrongLastname))
                
                TextField("Email", text: $email)
                    .padding()
                    .frame(width: 300, height: 50)
                    .background(Color.black.opacity(0.05))
                    .cornerRadius(10)
                    .border(.red, width: CGFloat(wrongEmail))
                
                SecureField("Password", text: $password)
                    .padding()
                    .frame(width: 300, height: 50)
                    .background(Color.black.opacity(0.05))
                    .cornerRadius(10)
                    .border(.red, width: CGFloat(wrongPassword))
                
                SecureField("Repeat Password", text: $passwordRepeat)
                    .padding()
                    .frame(width: 300, height: 50)
                    .background(Color.black.opacity(0.05))
                    .cornerRadius(10)
                    .border(.red, width: CGFloat(wrongPasswordRepeat))
                
                
                Button("Register") {
                    registerUser(firstname: firstname, lastname: lastname, email: email, password: password, passwordRepeat: passwordRepeat) }
                .foregroundColor(.white)
                .frame(width: 300, height: 50)
                .background(Color.red)
                .cornerRadius(10)
            }
        }
    }
}

func registerUser(firstname: String, lastname: String, email: String, password: String, passwordRepeat: String) {
        //Function to add the account
    }

#Preview {
    ContentView()
}
