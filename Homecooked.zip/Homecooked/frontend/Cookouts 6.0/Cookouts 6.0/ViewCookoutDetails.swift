import SwiftUI

struct ViewCookoutDetails: View {
    var name: String
    var date: String
    var time: String
    var location: String
    var diningOption: String
    var allergens: [String]
    var price: Double

    var body: some View {
        ZStack {
            Color.orange
                .ignoresSafeArea()
            
            Circle()
                .scale(2.1)
                .foregroundColor(.white.opacity(0.15))
            Circle()
                .scale(1.9)
                .foregroundColor(.white)
            
            VStack(alignment: .leading, spacing: 20) {
                Text("Cookout Details")
                    .font(.largeTitle)
                    .bold()
                    .padding(.top, 20)
                    .padding(.bottom, 20)
                    .frame(maxWidth: .infinity)
                    .multilineTextAlignment(.center)
                
                // Display cookout details
                Group {
                    DetailRow(label: "Name", value: name)
                        .padding()
                        .frame(width: 340, height: 50)
                        .background(Color.black.opacity(0.05))
                        .cornerRadius(10)
                    DetailRow(label: "Date", value: date)
                        .padding()
                        .frame(width: 340, height: 50)
                        .background(Color.black.opacity(0.05))
                        .cornerRadius(10)
                    DetailRow(label: "Time", value: time)
                        .padding()
                        .frame(width: 340, height: 50)
                        .background(Color.black.opacity(0.05))
                        .cornerRadius(10)
                    DetailRow(label: "Location", value: location)
                        .padding()
                        .frame(width: 340, height: 50)
                        .background(Color.black.opacity(0.05))
                        .cornerRadius(10)
                    DetailRow(label: "Dining Option", value: diningOption)
                        .padding()
                        .frame(width: 340, height: 50)
                        .background(Color.black.opacity(0.05))
                        .cornerRadius(10)
                    
                    // Display allergens
                    VStack(alignment: .leading) {
                        Text("Allergens:")
                            .font(.headline)
                        ForEach(allergens, id: \.self) { allergen in
                            Text("- \(allergen)")
                                .padding(.leading, 10)
                        }
                    }
                    
                    DetailRow(label: "Price", value: String(format: "$%.2f", price)).padding()
                        .frame(width: 340, height: 50)
                        .background(Color.black.opacity(0.05))
                        .cornerRadius(10)
                }
                .padding(.horizontal)
                
                Spacer()
            }
            .padding()
            .frame(maxWidth: .infinity, alignment: .leading)
        }
    }
}

struct DetailRow: View {
    var label: String
    var value: String
    
    var body: some View {
        HStack {
            Text("\(label):")
                .font(.headline)
            Spacer()
            Text(value)
        }
        .padding(.vertical, 5)
    }
}

#Preview {
    ViewCookoutDetails(name: "BBQ - Alice", date: "2024-11-10", time: "17:00", location: "City Park", diningOption: "Pick up", allergens: ["Dairy", "Peanuts"], price: 15.0)
}
