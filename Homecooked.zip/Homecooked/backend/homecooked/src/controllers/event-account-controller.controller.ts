import {
  Count,
  CountSchema,
  Filter,
  FilterExcludingWhere,
  repository,
  Where,
} from '@loopback/repository';
import {
  post,
  param,
  get,
  getModelSchemaRef,
  patch,
  put,
  del,
  requestBody,
  response,
} from '@loopback/rest';
import {EventAccountJoint} from '../models';
import {EventAccountJointRepository} from '../repositories';

export class EventAccountControllerController {
  constructor(
    @repository(EventAccountJointRepository)
    public eventAccountJointRepository : EventAccountJointRepository,
  ) {}

  @post('/event-account-joints')
  @response(200, {
    description: 'EventAccountJoint model instance',
    content: {'application/json': {schema: getModelSchemaRef(EventAccountJoint)}},
  })
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(EventAccountJoint, {
            title: 'NewEventAccountJoint',
            
          }),
        },
      },
    })
    eventAccountJoint: EventAccountJoint,
  ): Promise<EventAccountJoint> {
    return this.eventAccountJointRepository.create(eventAccountJoint);
  }

  @get('/event-account-joints/count')
  @response(200, {
    description: 'EventAccountJoint model count',
    content: {'application/json': {schema: CountSchema}},
  })
  async count(
    @param.where(EventAccountJoint) where?: Where<EventAccountJoint>,
  ): Promise<Count> {
    return this.eventAccountJointRepository.count(where);
  }

  @get('/event-account-joints')
  @response(200, {
    description: 'Array of EventAccountJoint model instances',
    content: {
      'application/json': {
        schema: {
          type: 'array',
          items: getModelSchemaRef(EventAccountJoint, {includeRelations: true}),
        },
      },
    },
  })
  async find(
    @param.filter(EventAccountJoint) filter?: Filter<EventAccountJoint>,
  ): Promise<EventAccountJoint[]> {
    return this.eventAccountJointRepository.find(filter);
  }

  @patch('/event-account-joints')
  @response(200, {
    description: 'EventAccountJoint PATCH success count',
    content: {'application/json': {schema: CountSchema}},
  })
  async updateAll(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(EventAccountJoint, {partial: true}),
        },
      },
    })
    eventAccountJoint: EventAccountJoint,
    @param.where(EventAccountJoint) where?: Where<EventAccountJoint>,
  ): Promise<Count> {
    return this.eventAccountJointRepository.updateAll(eventAccountJoint, where);
  }

  @get('/event-account-joints/{id}')
  @response(200, {
    description: 'EventAccountJoint model instance',
    content: {
      'application/json': {
        schema: getModelSchemaRef(EventAccountJoint, {includeRelations: true}),
      },
    },
  })
  async findById(
    @param.path.number('id') id: number,
    @param.filter(EventAccountJoint, {exclude: 'where'}) filter?: FilterExcludingWhere<EventAccountJoint>
  ): Promise<EventAccountJoint> {
    return this.eventAccountJointRepository.findById(id, filter);
  }

  @patch('/event-account-joints/{id}')
  @response(204, {
    description: 'EventAccountJoint PATCH success',
  })
  async updateById(
    @param.path.number('id') id: number,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(EventAccountJoint, {partial: true}),
        },
      },
    })
    eventAccountJoint: EventAccountJoint,
  ): Promise<void> {
    await this.eventAccountJointRepository.updateById(id, eventAccountJoint);
  }

  @put('/event-account-joints/{id}')
  @response(204, {
    description: 'EventAccountJoint PUT success',
  })
  async replaceById(
    @param.path.number('id') id: number,
    @requestBody() eventAccountJoint: EventAccountJoint,
  ): Promise<void> {
    await this.eventAccountJointRepository.replaceById(id, eventAccountJoint);
  }

  @del('/event-account-joints/{id}')
  @response(204, {
    description: 'EventAccountJoint DELETE success',
  })
  async deleteById(@param.path.number('id') id: number): Promise<void> {
    await this.eventAccountJointRepository.deleteById(id);
  }
}
