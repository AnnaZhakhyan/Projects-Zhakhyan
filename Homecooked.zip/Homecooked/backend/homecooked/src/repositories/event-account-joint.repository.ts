import {inject} from '@loopback/core';
import {DefaultCrudRepository} from '@loopback/repository';
import {DbDataSource} from '../datasources';
import {EventAccountJoint, EventAccountJointRelations} from '../models';

export class EventAccountJointRepository extends DefaultCrudRepository<
  EventAccountJoint,
  typeof EventAccountJoint.prototype.id,
  EventAccountJointRelations
> {
  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
  ) {
    super(EventAccountJoint, dataSource);
  }
}
