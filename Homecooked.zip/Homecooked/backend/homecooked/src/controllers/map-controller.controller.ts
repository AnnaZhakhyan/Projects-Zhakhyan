import {
  Count,
  CountSchema,
  Filter,
  FilterExcludingWhere,
  repository,
  Where,
} from '@loopback/repository';
import {
  post,
  param,
  get,
  getModelSchemaRef,
  patch,
  put,
  del,
  requestBody,
  response,
} from '@loopback/rest';
import {Map} from '../models';
import {MapRepository} from '../repositories';

export class MapControllerController {
  constructor(
    @repository(MapRepository)
    public mapRepository : MapRepository,
  ) {}

  @post('/maps')
  @response(200, {
    description: 'Map model instance',
    content: {'application/json': {schema: getModelSchemaRef(Map)}},
  })
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Map, {
            title: 'NewMap',
            
          }),
        },
      },
    })
    map: Map,
  ): Promise<Map> {
    return this.mapRepository.create(map);
  }

  @get('/maps/count')
  @response(200, {
    description: 'Map model count',
    content: {'application/json': {schema: CountSchema}},
  })
  async count(
    @param.where(Map) where?: Where<Map>,
  ): Promise<Count> {
    return this.mapRepository.count(where);
  }

  @get('/maps')
  @response(200, {
    description: 'Array of Map model instances',
    content: {
      'application/json': {
        schema: {
          type: 'array',
          items: getModelSchemaRef(Map, {includeRelations: true}),
        },
      },
    },
  })
  async find(
    @param.filter(Map) filter?: Filter<Map>,
  ): Promise<Map[]> {
    return this.mapRepository.find(filter);
  }

  @patch('/maps')
  @response(200, {
    description: 'Map PATCH success count',
    content: {'application/json': {schema: CountSchema}},
  })
  async updateAll(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Map, {partial: true}),
        },
      },
    })
    map: Map,
    @param.where(Map) where?: Where<Map>,
  ): Promise<Count> {
    return this.mapRepository.updateAll(map, where);
  }

  @get('/maps/{id}')
  @response(200, {
    description: 'Map model instance',
    content: {
      'application/json': {
        schema: getModelSchemaRef(Map, {includeRelations: true}),
      },
    },
  })
  async findById(
    @param.path.number('id') id: number,
    @param.filter(Map, {exclude: 'where'}) filter?: FilterExcludingWhere<Map>
  ): Promise<Map> {
    return this.mapRepository.findById(id, filter);
  }

  @patch('/maps/{id}')
  @response(204, {
    description: 'Map PATCH success',
  })
  async updateById(
    @param.path.number('id') id: number,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Map, {partial: true}),
        },
      },
    })
    map: Map,
  ): Promise<void> {
    await this.mapRepository.updateById(id, map);
  }

  @put('/maps/{id}')
  @response(204, {
    description: 'Map PUT success',
  })
  async replaceById(
    @param.path.number('id') id: number,
    @requestBody() map: Map,
  ): Promise<void> {
    await this.mapRepository.replaceById(id, map);
  }

  @del('/maps/{id}')
  @response(204, {
    description: 'Map DELETE success',
  })
  async deleteById(@param.path.number('id') id: number): Promise<void> {
    await this.mapRepository.deleteById(id);
  }
}
