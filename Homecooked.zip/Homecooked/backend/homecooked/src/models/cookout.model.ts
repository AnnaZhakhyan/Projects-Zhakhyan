import {Entity, model, property} from '@loopback/repository';

@model({settings: {strict: false}})
export class Cookout extends Entity {
  @property({
    type: 'number',
    id: true,
    generated: true,
  })
  id?: number;

  @property({
    type: 'string',
    required: true,
  })
  dish: string;

  @property({
    type: 'number',
    required: true,
  })
  price: number;

  @property({
    type: 'number',
    required: true,
  })
  diningOption: number;

  @property({
    type: 'date',
    required: true,
  })
  date: string;

  @property({
    type: 'string',
    required: true,
  })
  picture: string;

  @property({
    type: 'geopoint',
    required: true,
  })
  location: string;

  @property({
    type: 'number',
    required: true,
  })
  time: number;

  @property({
    type: 'number',
    required: true,
  })
  cookID: number;

  // Define well-known properties here

  // Indexer property to allow additional data
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  [prop: string]: any;

  constructor(data?: Partial<Cookout>) {
    super(data);
  }
}

export interface CookoutRelations {
  // describe navigational properties here
}

export type CookoutWithRelations = Cookout & CookoutRelations;
