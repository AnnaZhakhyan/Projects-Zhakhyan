//
//  ContentView.swift
//  LoginRegister
//
//  Created by Philipp Ziglasch on 07.11.24.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        LoginView()
    }
}

#Preview {
    ContentView()
}
