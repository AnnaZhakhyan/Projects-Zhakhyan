import SwiftUI

struct Cookouts: Identifiable {
    var id = UUID()
    var dishName: String
    var cookName: String
    var date: String
    var time: String
    var picture: String
    var location: String
    var ispickup: Bool
    var allergens: [String]
    var price: Double
    
    var name: String {
        "\(dishName) - \(cookName)"
    }
    
    func convertImageToBase64(image: UIImage) -> String? {
        if let imageData = image.jpegData(compressionQuality: 1.0) {
            return imageData.base64EncodedString()
        } else {
            print("Failed to convert image to data.")
            return nil
        }
    }

    static func convertBase64ToImage(base64String: String) -> UIImage? {
        if let imageData = Data(base64Encoded: base64String, options: .ignoreUnknownCharacters) {
            return UIImage(data: imageData)
        } else {
            print("Failed to decode Base64 string.")
            return nil
        }
    }
}

struct ContentView: View {
    @State private var isPresentingAddEventView = false
    
    @State private var myCookouts: [Cookouts] = [
        Cookouts(dishName: "BBQ", cookName: "Alice", date: "2024-11-10", time: "17:00", picture: "", location: "City Park", ispickup: true, allergens: ["Dairy", "Peanut"], price: 15.0),
        Cookouts(dishName: "Goulash", cookName: "Milan", date: "2024-11-20", time: "18:30", picture: "", location: "Downtown Hall", ispickup: false, allergens: ["Wheat"], price: 25.0),
        Cookouts(dishName: "Pasta", cookName: "Claire", date: "2024-12-05", time: "12:00", picture: "", location: "Office Terrace", ispickup: false, allergens: [], price: 20.0),
        Cookouts(dishName: "Chinese food", cookName: "Dave", date: "2024-12-20", time: "19:00", picture: "", location: "Central Park", ispickup: true, allergens: ["Nuts"], price: 30.0)
    ]
    
    @State private var joinedCookouts: [Cookouts] = [
        Cookouts(dishName: "Fondue", cookName: "Emma", date: "2024-11-15", time: "19:00", picture: "", location: "Sandy Beach", ispickup: false, allergens: ["Shellfish"], price: 4.00),
        Cookouts(dishName: "Grill", cookName: "Frank", date: "2024-11-18", time: "16:00", picture: "", location: "Local Park", ispickup: true, allergens: ["Dairy", "Nuts"], price: 10.0),
        Cookouts(dishName: "BBQ", cookName: "Grace", date: "2024-11-27", time: "13:00", picture: "", location: "National Park", ispickup: false, allergens: [], price: 18.0)
    ]
    
    @State private var nearbyCookouts: [Cookouts] = [
        Cookouts(dishName: "Mac n Cheese", cookName: "Henry", date: "2024-11-22", time: "11:00", picture: "", location: "City Square", ispickup: false, allergens: ["Nuts", "Soy", "Fish"], price: 35.0),
        Cookouts(dishName: "Soup Mushroom", cookName: "Ivy", date: "2024-11-25", time: "14:00", picture: "", location: "Community Center", ispickup: true, allergens: [], price: 5.0),
        Cookouts(dishName: "BBQ", cookName: "Jack", date: "2024-12-03", time: "12:00", picture: "", location: "Green Farm", ispickup: false, allergens: ["Gluten"], price: 22.0)
    ]
    
    var body: some View {
        NavigationView {
            ZStack {
                Color.orange.ignoresSafeArea()
                Circle()
                    .scale(2.1)
                    .foregroundColor(.white.opacity(0.15))
                Circle()
                    .scale(1.9)
                    .foregroundColor(.white)
                
                VStack {
                    Text("Cookouts")
                        .font(.largeTitle)
                        .bold()
                        .padding()
                    
                    ScrollView {
                        CookoutSectionView(
                            title: "My cookouts",
                            cookouts: myCookouts,
                            addAction: { isPresentingAddEventView = true }
                        )
                        
                        CookoutSectionView(title: "Joined cookouts", cookouts: joinedCookouts)
                        
                        CookoutSectionView(title: "Nearby cookouts", cookouts: nearbyCookouts)
                    }
                    .sheet(isPresented: $isPresentingAddEventView) {
                        AddCookoutView(isPresented: $isPresentingAddEventView) { newCookout in
                            myCookouts.append(newCookout)
                        }
                    }
                }
                .padding()
            }
        }
    }
}

struct CookoutSectionView: View {
    var title: String
    var cookouts: [Cookouts]
    var addAction: (() -> Void)?
    
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Text(title)
                    .font(.headline)
                Spacer()
                if let addAction = addAction {
                    Button(action: addAction) {
                        Image(systemName: "plus")
                            .foregroundColor(.white)
                            .padding(8)
                            .background(Color.red)
                            .clipShape(Circle())
                    }
                    .buttonStyle(BorderlessButtonStyle())
                }
            }
            .padding(.horizontal)
            
            ForEach(cookouts) { cookout in
                NavigationLink(destination: ViewCookoutDetails(
                    name: cookout.name,
                    date: cookout.date,
                    time: cookout.time,
                    location: cookout.location,
                    diningOption: cookout.ispickup ? "Pick up" : "On-site",
                    allergens: cookout.allergens,
                    price: cookout.price
                )) {
                    HStack {
                        if let image = Cookouts.convertBase64ToImage(base64String: cookout.picture) {
                            Image(uiImage: image)
                                .resizable()
                                .scaledToFill()
                                .frame(width: 40, height: 40)
                                .clipShape(Circle())
                        } else {
                            Image(systemName: "person.circle.fill")
                                .resizable()
                                .scaledToFill()
                                .frame(width: 40, height: 40)
                                .clipShape(Circle())
                        }
                        
                        VStack(alignment: .leading, spacing: 5) {
                            Text(cookout.dishName)
                                .font(.headline)
                            Text(cookout.cookName)
                                .font(.subheadline)
                                .foregroundColor(.gray)
                        }
                        .padding()
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .background(Color.black.opacity(0.05))
                        .cornerRadius(10)
                        .frame(height: 70)
                    }
                    .padding(.bottom)
                }
            }
        }
    }
}

#Preview {
    ContentView()
}
