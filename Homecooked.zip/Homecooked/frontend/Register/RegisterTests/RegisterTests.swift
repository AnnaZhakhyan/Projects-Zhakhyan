//
//  RegisterTests.swift
//  RegisterTests
//
//  Created by Philipp Ziglasch on 07.11.24.
//

import Testing
@testable import Register

struct RegisterTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
