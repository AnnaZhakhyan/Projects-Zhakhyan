import {Entity, model, property} from '@loopback/repository';

@model()
export class Map extends Entity {
  @property({
    type: 'number',
    id: true,
    generated: true,
  })
  id?: number;

  @property({
    type: 'string',
    required: true,
  })
  city: string;

  @property({
    type: 'string',
    required: true,
  })
  street: string;

  @property({
    type: 'string',
    required: true,
  })
  housenumber: string;

  @property({
    type: 'string',
    required: true,
  })
  postcode: string;

  @property({
    type: 'string',
    required: true,
  })
  longitude: string;

  @property({
    type: 'string',
    required: true,
  })
  latitude: string;


  constructor(data?: Partial<Map>) {
    super(data);
  }
}

export interface MapRelations {
  // describe navigational properties here
}

export type MapWithRelations = Map & MapRelations;
