//
//  Cookouts_6_0Tests.swift
//  Cookouts 6.0Tests
//
//  Created by Anna Zhakhyan on 07/11/2024.
//

import Testing
@testable import Cookouts_6_0

struct Cookouts_6_0Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
