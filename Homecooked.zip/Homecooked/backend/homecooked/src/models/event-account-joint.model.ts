import {Entity, model, property} from '@loopback/repository';

@model({
  settings: {
    foreignKeys: {
      fk_event_account_accountId: {
        name: 'fk_event_account_accountId',
        entity: 'account',
        entityKey: 'id',
        foreignKey: 'accountId',
      },
      fk_event_cookoutId: {
        name: 'fk_event_cookoutId',
        entity: 'cookout',
        entityKey: 'id',
        foreignKey: 'cookoutId',
      },
    },
  },
})
export class EventAccountJoint extends Entity {
  @property({
    type: 'number',
    id: true,
    generated: true,
  })
  id?: number;


  constructor(data?: Partial<EventAccountJoint>) {
    super(data);
  }
}

export interface EventAccountJointRelations {
  // describe navigational properties here
}

export type EventAccountJointWithRelations = EventAccountJoint & EventAccountJointRelations;
