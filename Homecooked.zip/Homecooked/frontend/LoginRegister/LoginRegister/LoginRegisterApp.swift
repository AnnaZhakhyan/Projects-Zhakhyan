//
//  LoginRegisterApp.swift
//  LoginRegister
//
//  Created by Philipp Ziglasch on 07.11.24.
//

import SwiftUI

@main
struct LoginRegisterApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
