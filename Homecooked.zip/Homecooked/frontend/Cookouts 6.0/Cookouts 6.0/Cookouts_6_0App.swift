//
//  Cookouts_6_0App.swift
//  Cookouts 6.0
//
//  Created by Anna Zhakhyan on 07/11/2024.
//

import SwiftUI

@main
struct Cookouts_6_0App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
