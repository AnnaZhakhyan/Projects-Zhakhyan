## Use Case Descripton
<br>

| Name          | Register                                                                                                                                                                                                                                      | 
|---------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Actor         | User                                                                                                                                                                                                                                         |
| Description   | User registers an account                                                                                                                                                                                                                      |
| Pre-condition | -                                                                                                    |
| Scenario      | 1. Actor navigates to the register page. <br> 2. System open the register page. <br> 3. Actor fills in their data: first name, last name, email and password. <br> 4. System checks if the data is complete and unused and sends the data to the database. |
| Result        | Actor gets an account.                                                                                |
| Exception     | 4. System informs the actor which data is incompelete or already used. <br> 4.1. The actor changes their data.  | 
| Extensions    | -                                                                                                    |

<br>

| Name          | Log in                                                                                                                                                                                                                                       | 
|---------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Actor         | User                                                                                                                                                                                                                                         |
| Description   | User logs into their account                                                                                                                                                                                                          |
| Pre-condition | User has to be registered                                                                                                                                                                                                                    |
| Scenario      | 1. Actor navigates to the log in page. <br> 2. System opens login page. <br> 3. Actor fills in their login credentials. <br> 4. System checks if login credentials are correct and complete. <br> 5. If the actor's credentials are correct the actor gets logged in. |
| Result        | Actor gets logged in to their account.                                                                                                                                                                                                        |
| Exception     | 4. System informs the user that the login credentials were incorrect or incomplete. <br> 4.1. Actor fixes login credentials.                                                                                                          | 
| Extensions    | -                                                                                                   |

<br>

| Name          | Log out                                                                                                                                                                                                                                       | 
|---------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Actor         | User                                                                                                                                                                                                                                         |
| Description   | Actor logs out of their account                                                                       |
| Pre-condition | Actor has to be logged in                                                                            |
| Scenario      | 1. Actor selects account page. <br> 2. System offers account page. <br> 3. Actor logs out. |
| Result        | Actor gets logged out of their account.                                                                                                                                                                                                        |
| Exception     | -                                                                                                     | 
| Extensions    | -                                                                                                                                                                                                                                             |
<br>

| Name          | Create a new cookout                                                                                                                                                                                                                                       | 
|---------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Actor         | User                                                                                                                                                                                                                                         |
| Description   | User creates a new cookout                                                                      |
| Pre-condition | User has to be logged in                                                                            |
| Scenario      | 1. Actor selects the plus icon. <br> 2. System opens the "Add cookout" page. <br> 3. Actor fills in he following details dish name, dish description, dish image, location, date and time and dining option, price and allergens and presses the "Save cookout" button . <br> 4.System saves the choices of the Actor.|
| Result        | Actor successfully creates a cookout.                                                                                                                                                                                                        |
| Exception     | 4a.System alerts the Actor of the fact that some information provided was incorrect/incomplete. 5.User fixes the details that need fixing.                                                                                                   | 
| Extensions    | -                                                                                                                                                   
<br>

| Name          | View cookout details                                                                                                                                                                                                                                       | 
|---------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Actor         | User                                                                                                                                                                                                                                         |
| Description   | User views the cookout details of a desired cookout                                                                      |
| Pre-condition | User has to be logged in                                                                            |
| Scenario      | 1. Actor selects the desired cookout from the page. <br> 2. System opens the "View cookout details" page. <br> 3.Actor views the details on the page which includes he name of the dish, the date of the cookout, the time of the cookout, the location of the cookout, description, the dining option, the allergens and the price.|
| Result        | Actor successfully views the details of a desired cookout.                                                                                                                                                                                                        |
| Exception     |                                                                                                  | 
| Extensions    | -                                                                                                                                                                                                                                     
<br>

| Name          | View all relevant cookouts                                                                                                                                                                                                                                      | 
|---------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Actor         | User                                                                                                                                                                                                                                         |
| Description   | User views all of the upcoming cookouts, their own and already joined cookouts.                                                                      |
| Pre-condition | User has to be logged in                                                                            |
| Scenario      | 1. Actor navigates to the "View all cookouts" page. <br> 2. System opens the "View all cookouts" page. <br> 3.Actor views all of the upcoming cookouts, their own and already joined cookouts.|
| Result        | Actor successfully views all cookouts.                                                                                                                                                                                                        |
| Exception     |                                                                                                  | 
| Extensions    | -                                                                                                                               

<br>

| Name          | Join cookout                                                                                                                                                                                                                                      | 
|---------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Actor         | User                                                                                                                                                                                                                                         |
| Description   | Actor joins a cookout.                                                                      |
| Pre-condition | User has to be logged in                                                                            |
| Scenario      | 1. Actor navigates to the "View all cookouts" page. <br> 2. System opens the "View all cookouts" page. <br> 3.Actor views all of the cookouts and clicks on the join button next to the desired cookout. <br> 4.System saves the actor's choice and switches the button from "Join" to "Joined"|
| Result        | Actor successfully views all cookouts.                                                                                                                                                                                                        |
| Exception     | 4a.System doesn't do anything because the actor tries joining a cookout that is already joined by them. | 
| Extensions    | -                                                                                                                                                     
