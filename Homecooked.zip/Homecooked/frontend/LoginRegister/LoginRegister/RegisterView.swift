//
//  RegisterView.swift
//  LoginRegister
//
//  Created by Philipp Ziglasch on 07.11.24.
//

import SwiftUI
import Foundation

enum RequestError: Error {
case invalidURL
case missingData
case httpError
}

struct Account: Codable, Hashable {
    var id: Int? = nil
    let firstname: String
    let lastname: String
    let email: String
    let password: String
}


struct RegisterView: View {
    @State private var firstname = ""
    @State private var lastname = ""
    @State private var email = ""
    @State private var password = ""
    @State private var passwordRepeat = ""
    
    @State private var wrongFirstname = 0
    @State private var wrongLastname = 0
    @State private var wrongEmail = 0
    @State private var wrongPassword = 0
    @State private var wrongPasswordRepeat = 0
    
    var body: some View {
        ZStack {
            Color.orange
                .ignoresSafeArea()
            Circle()
                .scale(1.7)
                .foregroundColor(.white.opacity(0.15))
            Circle()
                .scale(1.35)
                .foregroundColor(.white)
            
            VStack{
                Text("Register")
                    .font(.largeTitle)
                    .bold()
                    .padding()
                
                TextField("Firstname", text: $firstname)
                    .padding()
                    .frame(width: 300, height: 50)
                    .background(Color.black.opacity(0.05))
                    .cornerRadius(10)
                    .border(.red, width: CGFloat(wrongFirstname))
                
                TextField("Lastname", text: $lastname)
                    .padding()
                    .frame(width: 300, height: 50)
                    .background(Color.black.opacity(0.05))
                    .cornerRadius(10)
                    .border(.red, width: CGFloat(wrongLastname))
                
                TextField("Email", text: $email)
                    .padding()
                    .frame(width: 300, height: 50)
                    .background(Color.black.opacity(0.05))
                    .cornerRadius(10)
                    .border(.red, width: CGFloat(wrongEmail))
                
                SecureField("Password", text: $password)
                    .padding()
                    .frame(width: 300, height: 50)
                    .background(Color.black.opacity(0.05))
                    .cornerRadius(10)
                    .border(.red, width: CGFloat(wrongPassword))
                
                SecureField("Repeat Password", text: $passwordRepeat)
                    .padding()
                    .frame(width: 300, height: 50)
                    .background(Color.black.opacity(0.05))
                    .cornerRadius(10)
                    .border(.red, width: CGFloat(wrongPasswordRepeat))
                
                Button("Register") {
                    guard validateInputs() else { return }
                    Task {
                        do {
                            let account = Account(
                                firstname: firstname,
                                lastname: lastname,
                                email: email,
                                password: password
                            )
                            try await registerUser(urlString: "http://127.0.0.1:3000/", account: account)
                        } catch {
                            print("Registration failed: \(error)")
                        }
                    }
                }
                .foregroundColor(.white)
                .frame(width: 300, height: 50)
                .background(Color.red)
                .cornerRadius(10)
            }
        }
    }
    
    func validateInputs() -> Bool {
        var isValid = true
        
        wrongFirstname = firstname.isEmpty ? 2 : 0
        wrongLastname = lastname.isEmpty ? 2 : 0
        wrongEmail = !email.contains("@") ? 2 : 0
        wrongPassword = password.isEmpty ? 2 : 0
        wrongPasswordRepeat = password != passwordRepeat ? 2 : 0
        
        if wrongFirstname > 0 || wrongLastname > 0 || wrongEmail > 0 || wrongPassword > 0 || wrongPasswordRepeat > 0 {
            isValid = false
        }
        
        return isValid
    }
    
    func registerUser(urlString: String, account: Account) async throws {
        //Function to add the account
        guard let url = URL(string: urlString) else {
            throw RequestError.invalidURL
        }
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        
        let encoder = JSONEncoder()
        request.httpBody = try encoder.encode(account)
        
        let (_, response) = try await URLSession.shared.data(for: request)
        
        guard let httpResponse = response as? HTTPURLResponse, 200..<300 ~= httpResponse.statusCode else {
            throw RequestError.httpError
        }
    }
}
