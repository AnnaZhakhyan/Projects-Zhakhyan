import SwiftUI

enum DiningOption: String, CaseIterable, Identifiable {
    case pickUp = "Pick up"
    case eatThere = "Eat there"
    case both = "Pick up and eat there"
    
    var id: String { self.rawValue }
}

struct AddCookoutView: View {
    @Binding var isPresented: Bool
    var onSave: (Cookouts) -> Void
    
    @State private var name = ""
    @State private var selectedDate = Date()
    @State private var location = ""
    @State private var selectedDiningOption: DiningOption = .pickUp
    @State private var price = 0.0
    @State private var selectedAllergens: [String] = []
    
    let allergenOptions = ["Milk", "Eggs", "Peanuts", "Tree Nuts", "Fish", "Crustaceans", "Wheat", "Soy", "Sesame"]
    
    
    
    
    
    
    var body: some View {
        NavigationView {
            ZStack {
                Color.orange.ignoresSafeArea()
                
                Circle()
                    .scale(2.1)
                    .foregroundColor(.white.opacity(0.15))
                Circle()
                    .scale(1.9)
                    .foregroundColor(.white)
  
                
                ScrollView {
                    VStack {
                        Text("Add Cookout")
                            .font(.largeTitle)
                            .bold()
                            .padding()
                        
                        TextField("Event Name", text: $name)
                            .padding()
                            .frame(width: 300, height: 50)
                            .background(Color.black.opacity(0.05))
                            .cornerRadius(10)
                        
                        HStack(spacing: 10) {
                            // Date Picker
                            DatePicker("Date", selection: $selectedDate, displayedComponents: .date)
                                .labelsHidden()
                                .padding()
                                .frame(width: 140, height: 50)
                                .background(Color.black.opacity(0.05))
                                .cornerRadius(10)
                            
                            // Time Picker
                            DatePicker("Time", selection: $selectedDate, displayedComponents: .hourAndMinute)
                                .labelsHidden()
                                .padding()
                                .frame(width: 140, height: 50)
                                .background(Color.black.opacity(0.05))
                                .cornerRadius(10)
                        }
                        .padding(.vertical, 10)
                        
                        TextField("Location", text: $location)
                            .padding()
                            .frame(width: 300, height: 50)
                            .background(Color.black.opacity(0.05))
                            .cornerRadius(10)
                        
                        Picker("Dining Option", selection: $selectedDiningOption) {
                            ForEach(DiningOption.allCases) { option in
                                Text(option.rawValue).tag(option)
                            }
                        }
                        .padding()
                        .frame(width: 300, height: 50)
                        .background(Color.black.opacity(0.05))
                        .cornerRadius(10)
                        
                        TextField("Price", value: $price, format: .currency(code: "EUR"))
                            .padding()
                            .frame(width: 300, height: 50)
                            .background(Color.black.opacity(0.05))
                            .cornerRadius(10)
                        
                        VStack(alignment: .leading) {
                            Text("Allergens:")
                                .font(.headline)
                            
                            ForEach(allergenOptions, id: \.self) { allergen in
                                Toggle(isOn: Binding(
                                    get: { selectedAllergens.contains(allergen) },
                                    set: { isSelected in
                                        if isSelected {
                                            selectedAllergens.append(allergen)
                                        } else {
                                            selectedAllergens.removeAll { $0 == allergen }
                                        }
                                    }
                                )) {
                                    Text(allergen)
                                }
                            }
                        }
                        .padding()
                        .frame(width: 300)
                        .background(Color.black.opacity(0.05))
                        .cornerRadius(10)
                        
                        Button("Save Cookout") {
                            let newCookout = Cookouts(
                                dishName: name,
                                cookName: "New Cook", // Adjust as needed
                                date: DateFormatter.localizedString(from: selectedDate, dateStyle: .short, timeStyle: .none),
                                time: DateFormatter.localizedString(from: selectedDate, dateStyle: .none, timeStyle: .short),
                                picture: "default_picture",
                                location: location,
                                ispickup: selectedDiningOption == .pickUp || selectedDiningOption == .both,
                                allergens: selectedAllergens,
                                price: price
                            )
                            onSave(newCookout)
                            isPresented = false
                        }
                        .foregroundColor(.white)
                        .frame(width: 300, height: 50)
                        .background(Color.red)
                        .cornerRadius(10)
                        .padding()
                    }
                }
            }
            .navigationBarItems(leading: Button("Cancel") {
                isPresented = false
            })
        }
    }
}

#Preview {
    AddCookoutView(isPresented: .constant(true)) { _ in }
}
